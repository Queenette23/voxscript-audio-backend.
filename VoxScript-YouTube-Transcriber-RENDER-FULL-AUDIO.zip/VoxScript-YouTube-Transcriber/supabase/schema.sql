-- VoxScript Supabase setup / migration
-- Safe to run on a project that already has the earlier VoxScript schema.

create table if not exists public.transcriptions (
  id uuid primary key default gen_random_uuid(),
  user_id uuid references auth.users(id) on delete cascade,
  source_url text,
  source_name text,
  language text,
  transcript text not null,
  created_at timestamptz not null default now()
);

-- Bring an existing table from the first VoxScript version up to date.
alter table public.transcriptions
  add column if not exists source_name text;

alter table public.transcriptions
  alter column source_url drop not null;

alter table public.transcriptions enable row level security;

-- Recreate table policies safely if this SQL is run more than once.
drop policy if exists "Users can view own transcriptions" on public.transcriptions;
drop policy if exists "Users can insert own transcriptions" on public.transcriptions;
drop policy if exists "Users can delete own transcriptions" on public.transcriptions;

create policy "Users can view own transcriptions"
on public.transcriptions for select
using (auth.uid() = user_id);

create policy "Users can insert own transcriptions"
on public.transcriptions for insert
with check (auth.uid() = user_id);

create policy "Users can delete own transcriptions"
on public.transcriptions for delete
using (auth.uid() = user_id);

-- Private media bucket for direct browser uploads.
-- The app uses short-lived signed URLs for the transcription backend.
insert into storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
values (
  'voxscript-media',
  'voxscript-media',
  false,
  104857600,
  array['audio/*', 'video/*']
)
on conflict (id) do update
set public = false,
    file_size_limit = 104857600,
    allowed_mime_types = array['audio/*', 'video/*'];

-- Recreate Storage policies safely.
drop policy if exists "Users can upload their own VoxScript media" on storage.objects;
drop policy if exists "Users can view their own VoxScript media" on storage.objects;
drop policy if exists "Users can delete their own VoxScript media" on storage.objects;

create policy "Users can upload their own VoxScript media"
on storage.objects for insert to authenticated
with check (
  bucket_id = 'voxscript-media'
  and (storage.foldername(name))[1] = auth.uid()::text
);

create policy "Users can view their own VoxScript media"
on storage.objects for select to authenticated
using (
  bucket_id = 'voxscript-media'
  and (storage.foldername(name))[1] = auth.uid()::text
);

create policy "Users can delete their own VoxScript media"
on storage.objects for delete to authenticated
using (
  bucket_id = 'voxscript-media'
  and (storage.foldername(name))[1] = auth.uid()::text
);
