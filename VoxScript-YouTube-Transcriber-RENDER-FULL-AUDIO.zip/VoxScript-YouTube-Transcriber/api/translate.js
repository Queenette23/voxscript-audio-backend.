export default async function handler(req, res) {
  if (req.method !== "POST") return res.status(405).json({ error: "Method not allowed" });
  const { transcript, targetLanguage } = req.body || {};
  if (!transcript || !targetLanguage) return res.status(400).json({ error: "Transcript and target language are required." });
  if (!process.env.GROQ_API_KEY) return res.status(501).json({ error: "Groq is not configured. Add GROQ_API_KEY in Vercel." });
  try {
    const response = await fetch("https://api.groq.com/openai/v1/chat/completions", {
      method: "POST",
      headers: { "Content-Type": "application/json", Authorization: `Bearer ${process.env.GROQ_API_KEY}` },
      body: JSON.stringify({
        model: "openai/gpt-oss-20b",
        temperature: 0,
        messages: [
          { role: "system", content: `Translate the user's transcript into ${targetLanguage}. Preserve meaning, names, line breaks, repetitions and speaker labels. Do not summarize, explain, add or remove content. Return only the translation.` },
          { role: "user", content: transcript }
        ]
      })
    });
    const data = await response.json().catch(() => ({}));
    if (!response.ok) return res.status(502).json({ error: data?.error?.message || "Translation failed." });
    return res.status(200).json({ translation: data?.choices?.[0]?.message?.content || "" });
  } catch (e) {
    return res.status(500).json({ error: "Could not translate the transcript." });
  }
}
