export default async function handler(req, res) {
  if (req.method !== "POST") return res.status(405).json({ error: "Method not allowed" });
  const { mediaUrl, language, start, end } = req.body || {};
  if (!mediaUrl) return res.status(400).json({ error: "Uploaded media URL is required." });
  if (!/^https?:\/\//i.test(mediaUrl)) return res.status(400).json({ error: "Invalid media URL." });
  if (!process.env.GROQ_API_KEY) return res.status(501).json({ error: "Groq is not configured. Add GROQ_API_KEY in Vercel." });
  try {
    const form = new FormData();
    form.append("model", "whisper-large-v3");
    form.append("url", mediaUrl);
    form.append("response_format", "verbose_json");
    form.append("temperature", "0");
    form.append("timestamp_granularities[]", "segment");
    form.append("timestamp_granularities[]", "word");
    form.append("prompt", "Transcribe exactly what is spoken or sung in the audio. Preserve repetitions, names, fillers and wording. Do not summarize, paraphrase, censor, translate, or invent words. For music, focus on the audible vocal words.");
    if (language && /^[a-z]{2}$/i.test(language)) form.append("language", language.toLowerCase());
    const groq = await fetch("https://api.groq.com/openai/v1/audio/transcriptions", {
      method: "POST", headers: { Authorization: `Bearer ${process.env.GROQ_API_KEY}` }, body: form
    });
    const data = await groq.json().catch(() => ({}));
    if (!groq.ok) return res.status(502).json({ error: data?.error?.message || "Groq transcription failed." });
    if (!data.text) return res.status(502).json({ error: "Groq returned no transcript." });
    return res.status(200).json({ transcript: data.text, language: data.language || language || null, segments: data.segments || [], words: data.words || [], source: "uploaded-media-groq-whisper", selection: { start: Number.isFinite(Number(start)) ? Number(start) : null, end: Number.isFinite(Number(end)) ? Number(end) : null } });
  } catch (e) {
    console.error("VoxScript upload transcription error", e);
    return res.status(500).json({ error: "Could not process the uploaded media." });
  }
}
