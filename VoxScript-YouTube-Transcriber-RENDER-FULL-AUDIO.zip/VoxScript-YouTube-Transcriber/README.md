# VoxScript — YouTube Full-Audio Transcriber

VoxScript keeps the existing website and Supabase features, but the YouTube extraction layer is now a separate Render backend.

## YouTube flow

**Paste YouTube link → Render/yt-dlp extracts the complete audio → FFmpeg converts it to MP3 → listen/download the full MP3 → Groq Whisper transcribes the full audio.**

The Render backend:
- Uses `yt-dlp` to obtain the best available audio from the supplied YouTube URL.
- Uses FFmpeg to create one complete MP3 from beginning to end.
- Keeps the extracted MP3 temporarily on Render so the browser can play/download it.
- Uses Groq `whisper-large-v3` for multilingual, accuracy-focused transcription.
- Uses a verbatim prompt intended to preserve repeated words, repeated chorus lines, fillers, names, slang and sung lyrics.
- Automatically splits very large MP3s into smaller transcription chunks when needed, while keeping the original full MP3 available for playback/download.

### Important accuracy note

The transcript is generated from the audio itself. It is not a summary or AI rewrite. Whisper can still mishear difficult lyrics, heavy music, low vocals, accents or unusual words, so no speech-to-text system can guarantee every lyric is perfect.

For lyrics you want to copy, the UI already includes **Copy** and **Download** transcript actions.

## Render deployment

1. Push this project to GitHub.
2. In Render, choose **New → Web Service** and connect the GitHub repository.
3. Render will use `render.yaml` / the Dockerfile in `render-audio-backend`.
4. Choose the **Free** plan while testing.
5. Add this environment variable:
   - `GROQ_API_KEY` = your Groq API key
6. Add:
   - `PUBLIC_BASE_URL` = your Render service URL, for example `https://voxscript-audio-backend.onrender.com`
7. Deploy and test:
   - `https://YOUR-RENDER-SERVICE.onrender.com/health`
   should return JSON with `"ok": true`.

## Connect the Vercel website to Render

Open `index.html` and find:

`const RENDER_BACKEND_URL="https://YOUR-RENDER-SERVICE.onrender.com";`

Replace the placeholder with your real Render URL.

Then redeploy the website to Vercel.

## Existing features preserved

- Supabase authentication/history
- MP3/audio upload
- Video upload
- Audio/video preview
- Separate translation
- Transcript download
- Copy transcript
- Mobile responsive UI

## Environment variables

For the Render backend:
- `GROQ_API_KEY`
- `PUBLIC_BASE_URL`

For the existing Vercel upload/translation functions:
- `GROQ_API_KEY`

The YouTube workflow no longer uses Tunelio.

## Hosting notes

Render Free services can spin down after 15 minutes of inactivity, so the first request after inactivity may take longer. The free service also has ephemeral local storage; extracted MP3s are temporary and are not intended as permanent storage.

Groq is a separate service and may have its own rate limits/pricing. The current project uses `whisper-large-v3` because this is the accuracy-focused multilingual option documented by Groq.

Only process media you own, have permission to use, or that is otherwise lawful to transcribe.
